from tendenci.apps.perms.managers import TendenciBaseManager

class EmergencyAnnouncementManager(TendenciBaseManager):
    """
    Model Manager
    """
    pass
