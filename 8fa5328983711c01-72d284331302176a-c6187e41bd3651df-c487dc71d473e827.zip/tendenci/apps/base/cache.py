# BASE CACHE KEYS
IMAGE_PREVIEW_CACHE = "image.preview."
RENDERED_CONTENT_CACHE = "rendered.content."