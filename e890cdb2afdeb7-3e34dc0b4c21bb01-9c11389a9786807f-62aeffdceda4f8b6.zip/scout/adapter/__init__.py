from scout.adapter.mongo.base import MongoAdapter
from .client import get_connection
