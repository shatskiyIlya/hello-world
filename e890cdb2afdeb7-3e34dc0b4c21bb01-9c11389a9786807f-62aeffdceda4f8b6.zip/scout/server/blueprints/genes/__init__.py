# -*- coding: utf-8 -*-
from .views import genes_bp
