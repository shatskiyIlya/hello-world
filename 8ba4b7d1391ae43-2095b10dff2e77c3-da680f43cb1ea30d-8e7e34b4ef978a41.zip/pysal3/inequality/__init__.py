"""
:mod:`inequality` --- Spatial Inequality Analysis
=================================================

"""

from . import theil
from . import gini
