sids2
=====

North Carolina county SIDS death counts and rates
-------------------------------------------------
 
 * sids2.dbf:  attribute data
 * sids2.html: documentation
 * sids2.shp:  shapefile
 * sids2.shx:  spatial index
 * sids2.gal:  GAL file for spatial weights


Source: http://geodacenter.org/downloads/data-files/sids2.zip
