Documentation for all example data sets for PySAL can be found at

http://pysal.org/users/tutorials/examples.html

If you obtained this example data by downloading it as a separate zip file, it should be unzipped in the pysal directory, so that the path to the data herein would be like pysal/examples/rook31.dbf, for example. 
