virginia
========

Virginia counties shapefile
---------------------------

  * virginia.shp: Shapefile
  * virginia.shx: shapefile index
  * virginia.dbf: attributes
  * virginia.prj: shapefile projection
