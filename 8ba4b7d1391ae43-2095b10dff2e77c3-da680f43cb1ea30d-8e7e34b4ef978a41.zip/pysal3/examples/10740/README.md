10740
=====

Albuquerque Census 2000 Tract Data
----------------------------------

Albuquerque, New Mexico, 2000 Census Tracts (n = 141)

* 10740.dbf: attribute database file
* 10740.shp: shapefile
* 10740.shx: spatial index
* 10740_queen.gal: queen contiguity GAL format
* 10740_rook.gal: rook contiguity GAL format
