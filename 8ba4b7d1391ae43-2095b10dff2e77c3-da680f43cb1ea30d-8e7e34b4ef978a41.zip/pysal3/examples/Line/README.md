Point
=====

Point Shapefile
---------------

Used for testing
