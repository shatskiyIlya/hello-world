baltim
======

Baltimore house sales prices and hedonics
-----------------------------------------

* baltim.dbf attribute data
* baltim.shp shape file
* baltim.shx spatial index file
* baltim.tri.k12.kwt Kernel weights using a triangular kernel with 12 neares
  neighbors
* baltim_k4.gwt Nearest neighbor weights (4nn)
* baltim_q.gal Queen contiguity file
* baltimore.geojson

Point data, n=211, k= 17.
