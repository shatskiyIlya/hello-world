chicago
=======

Chicago neighborhoods
--------------------

 * Chicago77.dbf attribute file
 * Chicago77.shp shapefile
 * Chicago77.shx spatial index

Polygons, n=77, k=11
