mexico
======

Mexican states regional income 1940-2000
----------------------------------------

Data used in   Rey, S.J. and M.L.  Sastre Gutierrez. (2010) "Interregional inequality
dynamics in Mexico." Spatial Economic Analysis, 5: 277-298

* mexico.csv: attribute data
* mexico.gal: spatial weights in GAL format

Polygon data, n=32, k=13


