desmith
=======

Small data set to illustrate Moran's I statistic
------------------------------------------------

Figure 5-31 of de Smith, Goodchild and Longley (2015)

Polygons, n=12, k=1

Source: <http://www.spatialanalysisonline.com/>

Used with permission.
