burkitt
=======

Burkitt's lymphoma in the Western Nile district of Uganda
---------------------------------------------------------

 * burkitt.dbf attribute file
 * burkitt.shp shapefile
 * burkitt.shx spatial index

 Point data, n=188, k=6 
