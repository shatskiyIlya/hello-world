us_income
=========

Per-capita income for the lower 47 US states 1929-2010
------------------------------------------------------

 * us48.shp: shapefile 
 * us48.dbf: dbf for shapefile
 * us48.shx: index for shapefile
 * usjoin.csv: attribute data (comma delimited file)
