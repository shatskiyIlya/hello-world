juvenile
========

Residences of juvenile offenders in Cardiff, UK
-----------------------------------------------

 * juvenile.dbf attribute file
 * juvenile.gwt spatial weights
 * juvenile.shp shapefile
 * juvenile.shx spatial index

Point data, unknown coordinates, n=168, k=3. 

Source: http://geodacenter.org/downloads/data-files/juvenile.zip
