import datetime
version = "1.14.0dev"
stable_release_date = datetime.date(2016, 12, 9)
