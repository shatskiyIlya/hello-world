package org.watson.questionandanswer.response;

import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class QuestionAndAnswerResponse {

    private ResponseData question;
 
    /**
     * 
     * @return
     *     The question
     */
    public ResponseData getQuestion() {
        return question;
    }

    /**
     * 
     * @param question
     *     The question
     */
    public void setQuestion(ResponseData question) {
        this.question = question;
    }


}
