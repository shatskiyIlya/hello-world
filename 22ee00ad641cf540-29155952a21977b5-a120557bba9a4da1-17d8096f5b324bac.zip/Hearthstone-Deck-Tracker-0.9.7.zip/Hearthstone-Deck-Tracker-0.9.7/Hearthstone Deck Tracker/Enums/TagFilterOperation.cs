﻿namespace Hearthstone_Deck_Tracker.Enums
{
	public enum TagFilerOperation
	{
		And,
		Or
	}
}