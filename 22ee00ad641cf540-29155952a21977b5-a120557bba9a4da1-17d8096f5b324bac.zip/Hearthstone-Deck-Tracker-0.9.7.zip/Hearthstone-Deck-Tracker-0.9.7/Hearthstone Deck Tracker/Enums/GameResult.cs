namespace Hearthstone_Deck_Tracker.Enums
{
	public enum GameResult
	{
		None,
		Win,
		Loss,
		Draw
	}
}