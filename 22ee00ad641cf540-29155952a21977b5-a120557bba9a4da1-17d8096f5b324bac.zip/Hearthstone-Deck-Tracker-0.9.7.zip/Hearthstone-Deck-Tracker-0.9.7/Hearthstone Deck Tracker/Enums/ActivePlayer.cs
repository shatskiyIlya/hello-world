namespace Hearthstone_Deck_Tracker.Enums
{
	public enum ActivePlayer
	{
		Player,
		Opponent,
		None
	}
}