﻿namespace Hearthstone_Deck_Tracker.Enums.Hearthstone
{
	public enum TAG_CARDTYPE
	{
		INVALID,
		GAME,
		PLAYER,
		HERO,
		MINION,
		ABILITY,
		ENCHANTMENT,
		WEAPON,
		ITEM,
		TOKEN,
		HERO_POWER,
	}
}