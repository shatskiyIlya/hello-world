﻿namespace Hearthstone_Deck_Tracker.Enums.Hearthstone
{
	public enum TAG_MULLIGAN
	{
		INVALID,
		INPUT,
		DEALING,
		WAITING,
		DONE,
	}
}