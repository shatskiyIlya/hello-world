﻿namespace Hearthstone_Deck_Tracker.Enums
{
	public enum HeroClass
	{
		Druid,
		Hunter,
		Mage,
        Paladin,
		Priest,
		Rogue,
		Shaman,
		Warlock,
		Warrior
	}

	public enum HeroClassAll
	{
		All,
		Druid,
		Hunter,
		Mage,
		Paladin,
		Priest,
		Rogue,
		Shaman,
		Warlock,
		Warrior,
		Archived
	}
}