﻿namespace Hearthstone_Deck_Tracker.Enums
{
	public enum YesNo
	{
		Yes,
		No
	}
}