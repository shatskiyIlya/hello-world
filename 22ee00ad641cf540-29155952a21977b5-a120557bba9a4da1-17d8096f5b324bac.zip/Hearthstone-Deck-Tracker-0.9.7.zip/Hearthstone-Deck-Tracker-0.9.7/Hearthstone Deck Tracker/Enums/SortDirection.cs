namespace Hearthstone_Deck_Tracker.Enums
{
	public enum SortDirection
	{
		Up,
		Down
	}
}