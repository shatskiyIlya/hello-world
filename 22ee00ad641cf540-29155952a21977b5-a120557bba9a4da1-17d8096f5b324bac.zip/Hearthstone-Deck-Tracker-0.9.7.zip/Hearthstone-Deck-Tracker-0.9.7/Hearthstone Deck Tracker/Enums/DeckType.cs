﻿namespace Hearthstone_Deck_Tracker.Enums
{
	public enum DeckType
	{
		All,
		Arena,
		Constructed
	}
}