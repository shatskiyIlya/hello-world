﻿namespace Hearthstone_Deck_Tracker
{
	/// <summary>
	/// Interaction logic for HearthstoneTextBlock.xaml
	/// </summary>
	public partial class HearthstoneTextBlock
	{
		public HearthstoneTextBlock()
		{
			InitializeComponent();
		}
	}
}