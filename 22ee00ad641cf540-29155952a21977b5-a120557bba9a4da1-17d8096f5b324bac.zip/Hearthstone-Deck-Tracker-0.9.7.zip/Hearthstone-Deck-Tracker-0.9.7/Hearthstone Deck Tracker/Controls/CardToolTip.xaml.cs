﻿namespace Hearthstone_Deck_Tracker
{
	/// <summary>
	/// Interaction logic for CardToolTip.xaml
	/// </summary>
	public partial class CardToolTip
	{
		public CardToolTip()
		{
			InitializeComponent();
		}
	}
}