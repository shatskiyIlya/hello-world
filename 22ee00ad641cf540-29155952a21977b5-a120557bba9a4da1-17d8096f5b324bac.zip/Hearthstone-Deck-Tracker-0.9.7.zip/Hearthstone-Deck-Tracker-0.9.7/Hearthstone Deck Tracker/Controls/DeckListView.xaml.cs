﻿namespace Hearthstone_Deck_Tracker
{
	/// <summary>
	/// Interaction logic for DeckListView.xaml
	/// </summary>
	public partial class DeckListView
	{
		public DeckListView()
		{
			InitializeComponent();
		}
	}
}