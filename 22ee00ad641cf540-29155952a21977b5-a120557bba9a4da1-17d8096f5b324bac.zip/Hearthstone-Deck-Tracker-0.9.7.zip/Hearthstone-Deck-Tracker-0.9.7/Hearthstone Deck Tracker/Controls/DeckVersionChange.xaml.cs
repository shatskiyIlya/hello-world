﻿#region

using System.Windows.Controls;

#endregion

namespace Hearthstone_Deck_Tracker.Controls
{
	/// <summary>
	/// Interaction logic for DeckVersionChange.xaml
	/// </summary>
	public partial class DeckVersionChange : UserControl
	{
		public DeckVersionChange()
		{
			InitializeComponent();
		}
	}
}